# 0.1.2

Rework to make less extreme attack reduction and give methods around it. Also reworked most traits.

# 0.1.1

Rework to make less OP

# 0.1.0

Initial concept
